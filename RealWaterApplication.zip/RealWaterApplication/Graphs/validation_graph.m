function T = validation_graph(J_rw,Jp_rw,R2_rw,k0_rw,k1_rw,kp0_rw,kp1_rw,k0,kp0,k1,kp1)

figure()
T = tiledlayout(3,2);
nexttile
plot([0 max(max(kp0),max(k0))]*1.25,[0 max(max(kp0),max(k0))]*1.25,'Color',[0.8,0.8,0.8],'LineWidth',2)
hold on
scatter(k0,kp0,30,'LineWidth',1,'MarkerEdgeColor',[0.3 0.3 0.3]);
hold on
scatter(k0_rw,kp0_rw,'filled','MarkerEdgeColor',[0.3 0.3 0.3], 'MarkerFaceColor',[0 .75 .75]);
xlim([0 max(max(kp0),max(k0))]*1.25); ylim([0 max(max(kp0),max(k0))]*1.25);
xlabel('Oberved K_0 (L^{-2} m^4 h)','fontweight','bold','fontsize',10); ylabel('Predicted K_0 (L^{-2} m^4 h)','fontweight','bold','fontsize',10)
box on
title('k_0')
legend('','Training','Validation','Location','southeast')

nexttile
plot([0 max(max(kp1),max(k1))]*1.25,[0 max(max(kp1),max(k1))]*1.25,'Color',[0.8,0.8,0.8],'LineWidth',2)
hold on
scatter(k1,kp1,30,'LineWidth',1,'MarkerEdgeColor',[0.3 0.3 0.3]);
hold on
scatter(k1_rw,kp1_rw,'filled','MarkerEdgeColor',[0.3 0.3 0.3], 'MarkerFaceColor',[0 .75 .75]);
xlim([0 max(max(kp1),max(k1))]*1.25); ylim([0 max(max(kp1),max(k1))]*1.25);
xlabel('Oberved K_1 (L^{-1} m^2)','fontweight','bold','fontsize',10); ylabel('Predicted K_1 (L^{-1} m^2)','fontweight','bold','fontsize',10)
box on
title('k_1')
legend('Training','Real Water','Location','southeast')


nexttile([2 2])
a=[0 0.4470 0.7410];
b=[0.8500 0.3250 0.0980];
c=[0.6350 0.0780 0.1840];
col=[a;b;c];

for nn = 1:size(Jp_rw,2)
    c = col(nn,:);
scatter(J_rw(:,1),J_rw(:,nn+1),30,c,'LineWidth',1)
hold on
plot(J_rw(:,1),Jp_rw(:,nn),'LineWidth',1.5,'Color',c)
hold on

txt = ['R^2 =' num2str(R2_rw(nn),'%4.2f')];
NE = [max(xlim) max(ylim)]-[diff(xlim) 3*(nn-0.9)*diff(ylim)]*0.05;
text(NE(1),NE(2),txt,'VerticalAlignment','top', 'HorizontalAlignment','right','Color',c,'FontSize',10,'FontWeight','bold');

end
xlabel('Time (min)','fontweight','bold','fontsize',12); 
ylabel('Flux (L m^{-2} h^{-1})','fontweight','bold','fontsize',12);
box on
title('Model vs Experimental Flux Decline')
% 





% scatter(X_J(1:45,1),X_J(1:45,i+1),30,'LineWidth',1,'MarkerEdgeColor',[0.5 0.5 0.5])
% hold on
% plot(X_J(1:45,1),J(:,i),'LineWidth',3,'Color',col)
% xlim([0 45]); ylim([0 ll(ii)])
% txt = ['R^2 =' num2str(R2(i),'%4.2f')];
% NE = [max(xlim) max(ylim)]-[diff(xlim) diff(ylim)]*0.05;
% text(NE(1),NE(2),txt,'VerticalAlignment','top', 'HorizontalAlignment','right');
% title(str(ii))
% box on
% end
% 
% xlabel(T1,'Time (min)','fontweight','bold','fontsize',12); 
% ylabel(T1,'Flux (L m^{-2} h^{-1})','fontweight','bold','fontsize',12);
% 
% toc1 = toc(9:10,1); al1 = untrain_t(1:2,2); Al1 = (al1./toc1)*100;
% toc2 = toc(11:end,1); al2 = untrain_t(3:end,2); Al2 = (al2./toc2)*100;
% tsp1 = [0;a_t(1,2);a_t(1,2);60]; TOC1 = [toc1(1); toc1(1); toc1(2); toc1(2)]; AL1 = [Al1(1); Al1(1); Al1(2); Al1(2)];
% tsp2 = [0;a_t(2:end,2);60]; TOC2 = [toc2(1);toc2(1:end)]; AL2 = [Al2(1);Al2(1:end)];
% 
% 
% figure ()
% T2 = tiledlayout(1,2,'TileSpacing','compact');
% t1=tiledlayout(T2,2,1,'TileSpacing','tight'); % Inner layout
% nexttile(t1)
% yyaxis left
% plot(tsp1,TOC1,'-.o','LineWidth',1,'Color',Br1,'MarkerSize',4,'MarkerEdgeColor',Br1,...
%     'MarkerFaceColor',Br1)
% ylabel('TOC (mg L^{-1})','fontweight','bold','fontsize',12);
% ylim([0 9]); xlim([0 45]);
% yyaxis right 
% plot(tsp1,AL1,'-.o','LineWidth',1,'Color',Br2,'MarkerSize',4,'MarkerEdgeColor',Br2,...
%     'MarkerFaceColor',Br2)
% ylim([0 60]); xlim([0 45]);
% legend('TOC','Alginate','Location','southeast')
% ax = gca;
% ax.YAxis(1).Color = Br1;
% ax.YAxis(2).Color = Br2;
% xlim([0 45])
% title('A')
% nexttile(t1)
% scatter(X_Jt(1:45,1),X_Jt(1:45,2),30,'LineWidth',1,'MarkerEdgeColor',[0.5 0.5 0.5])
% hold on
% plot(X_Jt(1:45,1),J1(1:45),'LineWidth',3,'Color',R)
% hold on
% plot(X_Jt(1:45,1),J1_0(1:45),':','LineWidth',1,'Color',R)
% ylim([0 350]); xlim([0 45]);
% ylabel('Flux (L m^{-2} h^{-1})','fontweight','bold','fontsize',12);
% box on
% txt = ['R^2 =' num2str(R2_t(1),'%4.2f')];
% NE = [max(xlim) max(ylim)]-[diff(xlim) diff(ylim)]*0.05;
% text(NE(1),NE(2),txt,'VerticalAlignment','top', 'HorizontalAlignment','right');
% 
% t2=tiledlayout(T2,2,1,'TileSpacing','tight'); % Inner layout
% t2.Layout.Tile = 2;
% nexttile(t2)
% yyaxis left
% plot(tsp2,TOC2,'-.o','LineWidth',1,'Color',Br1,'MarkerSize',4,'MarkerEdgeColor',Br1,...
%     'MarkerFaceColor',Br1);
% ylim([0 9]); xlim([0 45]);
% yyaxis right
% plot(tsp2,AL2,'-.o','LineWidth',1,'Color',Br2,'MarkerSize',4,'MarkerEdgeColor',Br2,...
%     'MarkerFaceColor',Br2);
% ylim([0 60]); xlim([0 45]);
% ylabel('Alginate (%)','fontweight','bold','fontsize',12);
% legend('TOC','Alginate','Location','northwest')
% ax = gca;
% ax.YAxis(1).Color = Br1;
% ax.YAxis(2).Color = Br2;
% xlim([0 45])
% title('B')
% nexttile(t2)
% scatter(X_Jt(1:90,3),X_Jt(1:90,4),30,'LineWidth',1,'MarkerEdgeColor',[0.5 0.5 0.5])
% hold on
% plot(X_Jt(1:90,3),J2(1:90),'LineWidth',3,'Color',R)
% hold on
% plot(X_Jt(1:90,3),J2_0(1:90),':','LineWidth',1,'Color',R)
% ylim([0 350]); xlim([0 45]);
% box on
% txt = ['R^2 =' num2str(R2_t(2),'%4.2f')];
% NE = [max(xlim) max(ylim)]-[diff(xlim) diff(ylim)]*0.05;
% text(NE(1),NE(2),txt,'VerticalAlignment','top', 'HorizontalAlignment','right');
% 
% xlabel(T2,'Time (min)','fontweight','bold','fontsize',12); 
% 

end