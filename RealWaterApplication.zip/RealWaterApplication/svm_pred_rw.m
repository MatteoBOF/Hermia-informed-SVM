%% Predict k
function [Mdl_k0, Mdl_k1, k0, k1, pred_k0, pred_k1, k0_rw,k1_rw, rw_pred_k0, rw_pred_k1] = svm_pred(np,Np_rw,k0,k1,pred,rw_pred,k0_rw, k1_rw,model_pred0,model_pred1)

% Check wether regression for k0 (n=0) or k1 (n=1) should be used
%indeces corresponding to n=0 and n=1
idx0=np==0; idx1=np==1; % training
IDX0=Np_rw==0; IDX1=Np_rw==1; % real water


data0 = [k0 pred];  data0=idx0.*data0;  data0 = data0(any(data0,2),:);         
data1 = [k1 pred]; data1=idx1.*data1;  data1 = data1(any(data1,2),:);         
k0 = data0(:,1);  pred_k0 = data0(:,2:end);  k1 = data1(:,1);  pred_k1 = data1(:,2:end); 


DATA_rw0= [k0_rw rw_pred]; DATA_rw0=IDX0.*DATA_rw0;  DATA_rw0 = DATA_rw0(any(DATA_rw0,2),:);
DATA_rw1= [k1_rw rw_pred]; DATA_rw1=IDX1.*DATA_rw1;  DATA_rw1 = DATA_rw1(any(DATA_rw1,2),:); 
k0_rw=DATA_rw0(:,1); rw_pred_k0 = DATA_rw0(:,2:end);
k1_rw=DATA_rw1(:,1); rw_pred_k1 = DATA_rw1(:,2:end);



%% Support Vector Machine Regression
if model_pred0(1)==0
Mdl_k0 = fitrsvm([pred_k0;rw_pred_k0],[k0;k0_rw].*model_pred0(2),'KernelFunction','rbf','Standardize',true);
else
Mdl_k0 = fitrsvm([pred_k0;rw_pred_k0],[k0;k0_rw].*model_pred0(2),'KernelFunction','polynomial','PolynomialOrder',model_pred0(1),'Standardize',true,'Epsilon',model_pred0(3));
end

if model_pred1(1)==0
Mdl_k1 = fitrsvm([pred_k1;rw_pred_k1],[k1;k1_rw].*model_pred1(2),'KernelFunction','rbf','Standardize',true);
else
Mdl_k1 = fitrsvm([pred_k1;rw_pred_k1],[k1;k1_rw].*model_pred1(2),'KernelFunction','polynomial','PolynomialOrder',model_pred1(1),'Standardize',true,'Epsilon',model_pred1(3));
end

end
