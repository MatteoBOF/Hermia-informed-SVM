function [EEM,EEMrw,Ex,Em]=Import_EEM(EEM_dir,Data_dir)
%% Import Raw Data and convert to numerical values

cd(EEM_dir)

EEM1=readtable('V1_F1PEM.dat');EEM1 = table2array(EEM1);
Ex = EEM1(4:end,1); Em = EEM1(1,2:end); 
EEM1 = EEM1(4:end,2:end); EEM1 = reshape(EEM1,1,[]);

EEM2=readtable('V2_F1_2sPEM.dat');EEM2 = table2array(EEM2);
EEM2 = EEM2(4:end,2:end); EEM2 = reshape(EEM2,1,[]);

EEM3=readtable('V3_F1_1sPEM.dat');EEM3 = table2array(EEM3);
EEM3 = EEM3(4:end,2:end); EEM3 = reshape(EEM3,1,[]);

EEM4=readtable('V4_F1_1sPEM.dat');EEM4 = table2array(EEM4);
EEM4 = EEM4(4:end,2:end); EEM4 = reshape(EEM4,1,[]);

EEM5=readtable('V5_F1_1sPEM.dat');EEM5 = table2array(EEM5);
EEM5 = EEM5(4:end,2:end); EEM5 = reshape(EEM5,1,[]);

EEM6=readtable('V6_F1_1sPEM.dat');EEM6 = table2array(EEM6);
EEM6 = EEM6(4:end,2:end); EEM6 = reshape(EEM6,1,[]);

EEM7=readtable('V7_F2_1sPEM.dat');EEM7 = table2array(EEM7);
EEM7 = EEM7(4:end,2:end); EEM7 = reshape(EEM7,1,[]);

EEM8=readtable('V8_F1_1sPEM.dat');EEM8 = table2array(EEM8);
EEM8 = EEM8(4:end,2:end); EEM8 = reshape(EEM8,1,[]);

EEM9=readtable('V9_F1_1sPEM.dat');EEM9 = table2array(EEM9);
EEM9 = EEM9(4:end,2:end); EEM9 = reshape(EEM9,1,[]);

EEM10=readtable('V10_F1_1sPEM.dat');EEM10 = table2array(EEM10);
EEM10 = EEM10(4:end,2:end); EEM10 = reshape(EEM10,1,[]);

EEM11=readtable('V11_F1_1sPEM.dat'); EEM11 = table2array(EEM11);
EEM11 = EEM11(4:end,2:end); EEM11 = reshape(EEM11,1,[]);

EEM12=readtable('V12_F1_1sPEM.dat');EEM12 = table2array(EEM12);
EEM12 = EEM12(4:end,2:end); EEM12 = reshape(EEM12,1,[]);

EEM13=readtable('V13_F1_1sPEM.dat');EEM13 = table2array(EEM13);
EEM13 = EEM13(4:end,2:end); EEM13 = reshape(EEM13,1,[]);

EEM14=readtable('V14_F1_1sPEM.dat');EEM14 = table2array(EEM14);
EEM14 = EEM14(4:end,2:end); EEM14 = reshape(EEM14,1,[]);

EEM15=readtable('V15_F1_1sPEM.dat');EEM15 = table2array(EEM15);
EEM15 = EEM15(4:end,2:end); EEM15 = reshape(EEM15,1,[]);

EEM16=readtable('V16_F1_1sPEM.dat');EEM16 = table2array(EEM16);
EEM16 = EEM16(4:end,2:end); EEM16 = reshape(EEM16,1,[]);

EEM17=readtable('V17_F1_1sPEM.dat');EEM17 = table2array(EEM17);
EEM17 = EEM17(4:end,2:end); EEM17 = reshape(EEM17,1,[]);

EEM18=readtable('V18_F1_1sPEM.dat');EEM18 = table2array(EEM18);
EEM18 = EEM18(4:end,2:end); EEM18 = reshape(EEM18,1,[]);

EEM19=readtable('V19_F1_1sPEM.dat');EEM19 = table2array(EEM19);
EEM19 = EEM19(4:end,2:end); EEM19 = reshape(EEM19,1,[]);

EEM20=readtable('V20_F1_1sPEM.dat');EEM20 = table2array(EEM20);
EEM20 = EEM20(4:end,2:end); EEM20 = reshape(EEM20,1,[]);

EEM21=readtable('V21_F1_1sPEM.dat');EEM21 = table2array(EEM21);
EEM21 = EEM21(4:end,2:end); EEM21 = reshape(EEM21,1,[]);

EEM22=readtable('V22_F1_1sPEM.dat');EEM22 = table2array(EEM22);
EEM22 = EEM22(4:end,2:end); EEM22 = reshape(EEM22,1,[]);

EEM23=readtable('V23_F1_1sPEM.dat');EEM23 = table2array(EEM23);
EEM23 = EEM23(4:end,2:end); EEM23 = reshape(EEM23,1,[]);

EEM24=readtable('V24_F1_1sPEM.dat');EEM24 = table2array(EEM24);
EEM24 = EEM24(4:end,2:end); EEM24 = reshape(EEM24,1,[]);

EEM25=readtable('V25_F1_1sPEM.dat');EEM25 = table2array(EEM25);
EEM25 = EEM25(4:end,2:end); EEM25 = reshape(EEM25,1,[]);

EEM26=readtable('V26_F1_1sPEM.dat');EEM26 = table2array(EEM26);
EEM26 = EEM26(4:end,2:end); EEM26 = reshape(EEM26,1,[]);

EEM27=readtable('V27_F1PEM.dat');EEM27 = table2array(EEM27);
EEM27 = EEM27(4:end,2:end); EEM27 = reshape(EEM27,1,[]);

EEM28=readtable('V28_F1PEM.dat');EEM28 = table2array(EEM28);
EEM28 = EEM28(4:end,2:end); EEM28 = reshape(EEM28,1,[]);

EEM29=readtable('V29_F1PEM.dat');EEM29 = table2array(EEM29);
EEM29 = EEM29(4:end,2:end); EEM29 = reshape(EEM29,1,[]);

EEM30=readtable('V30_F1PEM.dat');EEM30 = table2array(EEM30);
EEM30 = EEM30(4:end,2:end); EEM30 = reshape(EEM30,1,[]);

%% Real Water experiments

EEMrw1=readtable('RW1_PEM.dat');EEMrw1 = table2array(EEMrw1);
EEMrw1 = EEMrw1(4:end,2:end); EEMrw1 = reshape(EEMrw1,1,[]);

EEMrw2=readtable('RW2_PEM.dat');EEMrw2 = table2array(EEMrw2);
EEMrw2 = EEMrw2(4:end,2:end); EEMrw2 = reshape(EEMrw2,1,[]);

EEMrw3=readtable('RW3_PEM.dat');EEMrw3 = table2array(EEMrw3);
EEMrw3 = EEMrw3(4:end,2:end); EEMrw3 = reshape(EEMrw3,1,[]);


EEM = [EEM1;EEM2;EEM3;EEM4;EEM5;EEM6;EEM7;EEM8;EEM9;EEM10;EEM11; EEM12;EEM13;EEM14;EEM15;EEM16;EEM17;EEM18;EEM19;...
    EEM20;EEM21;EEM22;EEM23;EEM24;EEM25;EEM26;EEM27;EEM28;EEM29;EEM30];

EEMrw = [EEMrw1; EEMrw2; EEMrw3];


cd(Data_dir)
end