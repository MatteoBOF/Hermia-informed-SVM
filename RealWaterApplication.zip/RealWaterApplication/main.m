clc
clear
close all

main_dir = 'C:...\RealWater';
Data_dir = 'C:...\RealWater\Data';
EEM_dir = 'C:...\EEM_raw';
Graphs_dir = 'C:...\RealWater\Graphs';




% Application of the Hermia-informed SVM model to real surface water

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% IMPORT DATA  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd(Data_dir)
%% Import fluorescence data
% EEM: training experiments
% EEMx: validation experiments at constant feed composition
% EEMx_t: validation experiments with time-dependent feed composition

[EEM,EEMrw,Ex,Em]=Import_EEM(EEM_dir,Data_dir);

%% Import Flux Decline and extract the initial fluxes
training_J = readtable('training_fluxes.xlsx'); training_J = table2array(training_J); % Training Flux Decline
realwater_J = readtable('validation_fluxes_rw.xlsx'); realwater_J = table2array(realwater_J); % Real Water Flux Decline
rw_j0 = realwater_J(1,2:end); % Initial Flux

%% Import TOC analysis and nominal composition
training_toc = readtable('train_toc.xlsx'); training_toc = table2array(training_toc); % TOC analysis of feed for training exps
realwater_toc = readtable('realwater_toc.xlsx'); realwater_toc=table2array(realwater_toc); % TOC analysis of feed for validation exps (1-8: constant Feed; 9-10: sudden change; 11-18: stepwise change)

% nominal (desired composition): humic acid, alginate, BSA, LMWs relative to TPC 1sr raw: key excitation/emission (linearized); 2-31: training exps; 32-39: validation (constant feed) exps
nominal_comp=readtable('train_composition.xlsx'); nominal_comp = table2array(nominal_comp); 

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% MODEL TRAINING and VALIDATION %%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd(main_dir)

%% EEM calibration
% train_c : training exps, predicted toc, HA, Al, BSA and LMW
% untrain_c : untrained exps, predicted toc, HA, Al, BSA and LMW
[train_comp,untrain_rw] = EEM_cal(EEM,EEMrw,nominal_comp,training_toc,realwater_toc);

%% Hermia Fitting to training data

% n_t = dominant fouling mechanism
% k0 = k parameters for n=0
% k1 = k parameters for n=1
% j0 = initial fluxes
% 95% confidence interval for k
% PAR = [0 1 k0 k1 IC_k0 IC_k1 R2_k0 R2_k1 j0]
% [n_t,k0,k1,j0,~,IC,~,PAR]=training_Hermia(training_J);

[n_t,k0,k1,j0,~,IC,~,PAR]=training_Hermia(training_J);
n_t(16)=1; % n for experiment 16 manually set to 1, see Tagliavini & Snyder ACS EST Water 2024

%% Fitting Hermia to real water experiments to compare predicted vs
% observed k parameter
[n_rw ,k0_rw k1_rw] = realwater_Hermia(realwater_J);

%% Predictor matrices 
%% Training (excluding realwater)
pred = zeros(size(j0,1),3);
pred(:,1) = j0;
pred(:,2) = training_toc;
pred(:,3) = (train_comp(:,2)./training_toc)*100;


%% Real Water only
rw_pred = zeros(size(rw_j0',1),3);
rw_pred(:,1) = rw_j0';
rw_pred(:,2) = realwater_toc;
rw_pred(:,3) = (untrain_rw(:,2)./realwater_toc)*100;



%% Support Vector Classification
class_model = [2 0.1]; % 0: radial basis function, 1/2/3 polynomial order, box constraint
% Train a SVM binary classification model (Mdl_class) for n=0 or n=1
%[Mdl_class] =  svm_class(n_t,pred,class_model); % Excluding real water
[Mdl_class] =  svm_class([n_t;n_rw],[pred;rw_pred],class_model); % Including real water

np = predict(Mdl_class,pred(:,1:3)); % predicted n parameter for training exps
Np_rw = predict(Mdl_class,rw_pred(:,1:3)); % predicted n parameter for real water exps

%% Support Vector Regression
model_pred0 = [2 1e3 max(PAR(:,5))]; %0: radial basis function, 1/2/3 polynomial order / scaling factor / epsilon
model_pred1 = [3 1e3 max(PAR(:,6))]; % 0: radial basis function, 1/2/3 polynomial order / scaling factor / epsilon

% Train a regression for k0 (Mdl_k0) or k1 (Mdl_k1) based on the SVM classification outcome
%[Mdl_k0, Mdl_k1, k0, k1, pred_k0, pred_k1,k0_rw,k1_rw, rw_pred_k0, rw_pred_k1] ...
%    = svm_pred(np,Np_rw,k0,k1,pred,rw_pred,k0_rw,k1_rw,model_pred0,model_pred1); % Excluding Real Water exps during training

[Mdl_k0, Mdl_k1, k0, k1, pred_k0, pred_k1,k0_rw,k1_rw, rw_pred_k0, rw_pred_k1] ...
    = svm_pred_rw(np,Np_rw,k0,k1,pred,rw_pred,k0_rw,k1_rw,model_pred0,model_pred1); % Including Real Water exps during training

kp0 = predict(Mdl_k0,pred_k0)/model_pred0(2);  % predicted k0 parameter for training exps
kp1 = predict(Mdl_k1,pred_k1)/model_pred1(2);  % predicted k1 parameter for training exps

kp0_rw = predict(Mdl_k0,rw_pred_k0)/model_pred0(2); % predicted k0 parameter for validation exps at constant feed
kp1_rw = predict(Mdl_k1,rw_pred_k1)/model_pred1(2); % predicted k1 parameter for validation exps at constant feed


%% Simulate-observed untrained data
[Jp_rw,R2_rw]=validation(Np_rw,kp0_rw,kp1_rw,realwater_J);


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% PLOT GRAPHS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cd(Graphs_dir)

T=validation_graph(realwater_J,Jp_rw,R2_rw,k0_rw,k1_rw,kp0_rw,kp1_rw,k0,kp0,k1,kp1);





