function [train_comp,untrain_rw] = EEM_cal(EEM,EEMrw,nominal_comp,training_toc,rw_toc)

HAi = nominal_comp(1,1); Ali = nominal_comp(1,2); BSAi = nominal_comp(1,3); LMWi = nominal_comp(1,4); % Key excitation/emission wavelength
HA_train_EEM = EEM(:,HAi); BSA_train_EEM = EEM(:,[HAi BSAi LMWi]); LMW_train_EEM = EEM(:,[HAi BSAi LMWi]); % EEM intesity at keys ex/em - training exps
HA_rw_EEM = EEMrw(:,HAi); BSA_rw_EEM = EEMrw(:,[HAi BSAi LMWi]); LMW_rw_EEM = EEMrw(:,[HAi BSAi LMWi]); % EEM intesity at keys ex/em - real water

% Nominal components concentrations - training exps
HA_train = nominal_comp(2:end,1).*training_toc; 
Al_train = nominal_comp(2:end,2).*training_toc;
BSA_train = nominal_comp(2:end,3).*training_toc;
LMW_train = nominal_comp(2:end,4).*training_toc;


%% Components calibration
% Linear regression coefficients
aHA = regress(HA_train,HA_train_EEM); 
aBSA = regress(BSA_train,BSA_train_EEM); 
aLMW = regress(LMW_train,LMW_train_EEM); 

% Predicted components conc. for training exp
HA_train_p = HA_train_EEM*aHA;
BSA_train_p = sum(aBSA.*BSA_train_EEM');
LMW_train_p = sum(aLMW.*LMW_train_EEM'); 
Al_train_p = training_toc - (HA_train_p + BSA_train_p' + LMW_train_p'); 
Al_train_p = max(Al_train_p,0.13);

% Predicted components conc. for real water
HA_rw_p = HA_rw_EEM*aHA; 
BSA_rw_p = sum(aBSA.*BSA_rw_EEM'); 
LMW_rw_p = sum(aLMW.*LMW_rw_EEM'); 
Al_rw_p = rw_toc - (HA_rw_p + BSA_rw_p'+LMW_rw_p'); 

% Store the predicted compositions for training, validation constant feed
% and validation variable feed
train_comp = [HA_train_p Al_train_p BSA_train_p' LMW_train_p'];
untrain_rw = [HA_rw_p Al_rw_p BSA_rw_p' LMW_rw_p']; 
end