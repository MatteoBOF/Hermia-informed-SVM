function [n_rw, k0_rw, k1_rw] = realwater_Hermia(training_J)

time=training_J(:,1)/60; % experiment time, converted to hours
j_data=training_J(:,2:end); % water fluxes for the 30 training experiments

%% Fit the training dataset to Hermia model with n being 0 or 1 and k varying continuously
n0 = [0 1];
AA = zeros(size(j_data,2),5);
%Sim_J =zeros(size(j_data,1),size(j_data,2)*2);
for y = 1:length(j_data(1,:))
j=j_data(:,y);
j(isnan(j))=0; % Convert flux missing values to 0
JJ=[time j]; idx=JJ(:,2)~=0; % Find the indices of missing values
JJ=JJ.*idx;JJ = JJ(any(JJ,2),:); % Remove missing values in the flux and corresponding time vector (because t and j needs same dimension)
j=JJ(:,2); t=JJ(:,1); % Extract time and flux
j0 = j(1); % Define initial flux for Hermia

%% fit for n=0 and n=1 and find best fitting
PAR = zeros(length(n0),5);
KK = zeros(length(n0),2);
for i = 1:length(n0)
    n = n0(i);
fun = @(k,t) Hermia(j0,t,n,k); % Assing external function Hermia to fun
k0=0.01; % initial guess for k
options = optimoptions('lsqcurvefit','Display','off');
[k,resnorm,residual,exitflag,output,lambda,jacobian] = lsqcurvefit(fun,k0,t,j,0,5,options); %Fit data

conf = nlparci(k,residual,'jacobian',jacobian); % Determine confidence interval on the estimated k
J = Hermia(j0,t,n,k); % Calculate flux-time for the best-fitting parameter k
Rsquare = 1-var(j-Hermia(j0,t,n,k))/var(j); % Calculate R square
PAR(i,:) = [n k conf(1) Rsquare j0]; %store results in a PAR vector [n k 95%IC Rsquare j0]
PARex(y,:) = reshape(PAR,1,[]);
KK(y,i)=k;
end



RR = PAR(:,4);  [~, I]=max(RR); % Compare and find max R-square between n=0 and n=1
%Jm = Hermia(j0,t,PAR(I,1),PAR(I,2));
AA(y,:) = PAR(I,:); % Result vecor of best fitting n and k
 % Result vecor of best fitting n and k
clear JJ t j idx J n
end

k0_rw = PARex(:,3);
k1_rw = PARex(:,4);
n_rw = AA(:,1);

end


