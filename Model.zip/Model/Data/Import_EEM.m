function [EEM,EEMx,EEMxt,Ex,Em]=Import_EEM(EEM_dir, Data_dir)
%% Import Raw Data and convert to numerical values

cd(EEM_dir)

EEM1=readtable('V1_F1PEM.dat');EEM1 = table2array(EEM1);
Ex = EEM1(4:end,1); Em = EEM1(1,2:end); 
EEM1 = EEM1(4:end,2:end); EEM1 = reshape(EEM1,1,[]);

EEM2=readtable('V2_F1_2sPEM.dat');EEM2 = table2array(EEM2);
EEM2 = EEM2(4:end,2:end); EEM2 = reshape(EEM2,1,[]);

EEM3=readtable('V3_F1_1sPEM.dat');EEM3 = table2array(EEM3);
EEM3 = EEM3(4:end,2:end); EEM3 = reshape(EEM3,1,[]);

EEM4=readtable('V4_F1_1sPEM.dat');EEM4 = table2array(EEM4);
EEM4 = EEM4(4:end,2:end); EEM4 = reshape(EEM4,1,[]);

EEM5=readtable('V5_F1_1sPEM.dat');EEM5 = table2array(EEM5);
EEM5 = EEM5(4:end,2:end); EEM5 = reshape(EEM5,1,[]);

EEM6=readtable('V6_F1_1sPEM.dat');EEM6 = table2array(EEM6);
EEM6 = EEM6(4:end,2:end); EEM6 = reshape(EEM6,1,[]);

EEM7=readtable('V7_F2_1sPEM.dat');EEM7 = table2array(EEM7);
EEM7 = EEM7(4:end,2:end); EEM7 = reshape(EEM7,1,[]);

EEM8=readtable('V8_F1_1sPEM.dat');EEM8 = table2array(EEM8);
EEM8 = EEM8(4:end,2:end); EEM8 = reshape(EEM8,1,[]);

EEM9=readtable('V9_F1_1sPEM.dat');EEM9 = table2array(EEM9);
EEM9 = EEM9(4:end,2:end); EEM9 = reshape(EEM9,1,[]);

EEM10=readtable('V10_F1_1sPEM.dat');EEM10 = table2array(EEM10);
EEM10 = EEM10(4:end,2:end); EEM10 = reshape(EEM10,1,[]);

EEM11=readtable('V11_F1_1sPEM.dat'); EEM11 = table2array(EEM11);
EEM11 = EEM11(4:end,2:end); EEM11 = reshape(EEM11,1,[]);

EEM12=readtable('V12_F1_1sPEM.dat');EEM12 = table2array(EEM12);
EEM12 = EEM12(4:end,2:end); EEM12 = reshape(EEM12,1,[]);

EEM13=readtable('V13_F1_1sPEM.dat');EEM13 = table2array(EEM13);
EEM13 = EEM13(4:end,2:end); EEM13 = reshape(EEM13,1,[]);

EEM14=readtable('V14_F1_1sPEM.dat');EEM14 = table2array(EEM14);
EEM14 = EEM14(4:end,2:end); EEM14 = reshape(EEM14,1,[]);

EEM15=readtable('V15_F1_1sPEM.dat');EEM15 = table2array(EEM15);
EEM15 = EEM15(4:end,2:end); EEM15 = reshape(EEM15,1,[]);

EEM16=readtable('V16_F1_1sPEM.dat');EEM16 = table2array(EEM16);
EEM16 = EEM16(4:end,2:end); EEM16 = reshape(EEM16,1,[]);

EEM17=readtable('V17_F1_1sPEM.dat');EEM17 = table2array(EEM17);
EEM17 = EEM17(4:end,2:end); EEM17 = reshape(EEM17,1,[]);

EEM18=readtable('V18_F1_1sPEM.dat');EEM18 = table2array(EEM18);
EEM18 = EEM18(4:end,2:end); EEM18 = reshape(EEM18,1,[]);

EEM19=readtable('V19_F1_1sPEM.dat');EEM19 = table2array(EEM19);
EEM19 = EEM19(4:end,2:end); EEM19 = reshape(EEM19,1,[]);

EEM20=readtable('V20_F1_1sPEM.dat');EEM20 = table2array(EEM20);
EEM20 = EEM20(4:end,2:end); EEM20 = reshape(EEM20,1,[]);

EEM21=readtable('V21_F1_1sPEM.dat');EEM21 = table2array(EEM21);
EEM21 = EEM21(4:end,2:end); EEM21 = reshape(EEM21,1,[]);

EEM22=readtable('V22_F1_1sPEM.dat');EEM22 = table2array(EEM22);
EEM22 = EEM22(4:end,2:end); EEM22 = reshape(EEM22,1,[]);

EEM23=readtable('V23_F1_1sPEM.dat');EEM23 = table2array(EEM23);
EEM23 = EEM23(4:end,2:end); EEM23 = reshape(EEM23,1,[]);

EEM24=readtable('V24_F1_1sPEM.dat');EEM24 = table2array(EEM24);
EEM24 = EEM24(4:end,2:end); EEM24 = reshape(EEM24,1,[]);

EEM25=readtable('V25_F1_1sPEM.dat');EEM25 = table2array(EEM25);
EEM25 = EEM25(4:end,2:end); EEM25 = reshape(EEM25,1,[]);

EEM26=readtable('V26_F1_1sPEM.dat');EEM26 = table2array(EEM26);
EEM26 = EEM26(4:end,2:end); EEM26 = reshape(EEM26,1,[]);

EEM27=readtable('V27_F1PEM.dat');EEM27 = table2array(EEM27);
EEM27 = EEM27(4:end,2:end); EEM27 = reshape(EEM27,1,[]);

EEM28=readtable('V28_F1PEM.dat');EEM28 = table2array(EEM28);
EEM28 = EEM28(4:end,2:end); EEM28 = reshape(EEM28,1,[]);

EEM29=readtable('V29_F1PEM.dat');EEM29 = table2array(EEM29);
EEM29 = EEM29(4:end,2:end); EEM29 = reshape(EEM29,1,[]);

EEM30=readtable('V30_F1PEM.dat');EEM30 = table2array(EEM30);
EEM30 = EEM30(4:end,2:end); EEM30 = reshape(EEM30,1,[]);

%% Untraining data constant feed (X1,X2,X4,X6,X7,X8,X9,X10)

EEMX1=readtable('X1_F1PEM.dat');EEMX1 = table2array(EEMX1);
EEMX1 = EEMX1(4:end,2:end); EEMX1 = reshape(EEMX1,1,[]);

EEMX2=readtable('X2_F1PEM.dat');EEMX2 = table2array(EEMX2);
EEMX2 = EEMX2(4:end,2:end); EEMX2 = reshape(EEMX2,1,[]);

EEMX3=readtable('X4_F1PEM.dat');EEMX3 = table2array(EEMX3);
EEMX3 = EEMX3(4:end,2:end); EEMX3 = reshape(EEMX3,1,[]);

EEMX4=readtable('X6_F1PEM.dat');EEMX4 = table2array(EEMX4);
EEMX4 = EEMX4(4:end,2:end); EEMX4 = reshape(EEMX4,1,[]);

EEMX5=readtable('X7_F1PEM.dat');EEMX5 = table2array(EEMX5);
EEMX5 = EEMX5(4:end,2:end); EEMX5 = reshape(EEMX5,1,[]);

EEMX6=readtable('X8_F1PEM.dat');EEMX6 = table2array(EEMX6);
EEMX6 = EEMX6(4:end,2:end); EEMX6 = reshape(EEMX6,1,[]);

EEMX7=readtable('X9_F1PEM.dat');EEMX7 = table2array(EEMX7);
EEMX7 = EEMX7(4:end,2:end); EEMX7 = reshape(EEMX7,1,[]);

EEMX8=readtable('X10_F1PEM.dat');EEMX8 = table2array(EEMX8);
EEMX8 = EEMX8(4:end,2:end); EEMX8 = reshape(EEMX8,1,[]);

%% time dependent exp (X3 and X5)
EEMXt1=readtable('X3_F1PEM.dat');EEMXt1 = table2array(EEMXt1);
EEMXt1 = EEMXt1(4:end,2:end); EEMXt1 = reshape(EEMXt1,1,[]);

EEMXt2=readtable('X3_F2PEM.dat');EEMXt2 = table2array(EEMXt2);
EEMXt2 = EEMXt2(4:end,2:end); EEMXt2 = reshape(EEMXt2,1,[]);

EEMXt3=readtable('X5_F1PEM.dat');EEMXt3 = table2array(EEMXt3);
EEMXt3 = EEMXt3(4:end,2:end); EEMXt3 = reshape(EEMXt3,1,[]);

EEMXt4=readtable('X5_F2PEM.dat');EEMXt4 = table2array(EEMXt4);
EEMXt4 = EEMXt4(4:end,2:end); EEMXt4 = reshape(EEMXt4,1,[]);

EEMXt5=readtable('X5_F3PEM.dat');EEMXt5 = table2array(EEMXt5);
EEMXt5 = EEMXt5(4:end,2:end); EEMXt5 = reshape(EEMXt5,1,[]);

EEMXt6=readtable('X5_F4PEM.dat');EEMXt6 = table2array(EEMXt6);
EEMXt6 = EEMXt6(4:end,2:end); EEMXt6 = reshape(EEMXt6,1,[]);

EEMXt7=readtable('X5_F5PEM.dat');EEMXt7 = table2array(EEMXt7);
EEMXt7 = EEMXt7(4:end,2:end); EEMXt7 = reshape(EEMXt7,1,[]);

EEMXt8=readtable('X5_F6PEM.dat');EEMXt8 = table2array(EEMXt8);
EEMXt8 = EEMXt8(4:end,2:end); EEMXt8 = reshape(EEMXt8,1,[]);

EEMXt9=readtable('X5_F7PEM.dat');EEMXt9 = table2array(EEMXt9);
EEMXt9 = EEMXt9(4:end,2:end); EEMXt9 = reshape(EEMXt9,1,[]);

EEMXt10=readtable('X5_F8PEM.dat');EEMXt10 = table2array(EEMXt10);
EEMXt10 = EEMXt10(4:end,2:end); EEMXt10 = reshape(EEMXt10,1,[]);


EEM = [EEM1;EEM2;EEM3;EEM4;EEM5;EEM6;EEM7;EEM8;EEM9;EEM10; EEM11; EEM12;EEM13;EEM14;EEM15;EEM16;EEM17;EEM18;EEM19;...
    EEM20;EEM21;EEM22;EEM23;EEM24;EEM25;EEM26;EEM27;EEM28;EEM29;EEM30];

EEMx = [EEMX1; EEMX2; EEMX3; EEMX4; EEMX5; EEMX6; EEMX7; EEMX8];

EEMxt = [EEMXt1; EEMXt2; EEMXt3; EEMXt4; EEMXt5; EEMXt6; EEMXt7;EEMXt8;EEMXt9;EEMXt10];

cd(Data_dir)
end