
function [J]=Hermia_tt(j0,tt,n,k,a)
%a=a/0.5;
a = [1; a;length(tt)];
J=zeros([],1);
ti=1;
for i=1:length(a)-1 
t=tt(a(i):a(i+1));
tf=ti+length(t)-1;
J(ti:tf)=Hermia(j0,t,n(i),k(i));
j0=J(end);
ti = tf;
end

end