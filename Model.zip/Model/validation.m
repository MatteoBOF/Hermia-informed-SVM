function [t,J, R2]=validation(Np,kp0_x,kp1_x,X_J)
X_j0 = X_J(1,2:end)'; 

c0=1;c1=1; k_x = zeros(length(Np),1);
for y=1:length(Np)
if Np(y)==0
    k_x(y)=kp0_x(c0);
    c0 = c0+1;
else 
    %Np(y)==1;
    k_x(y)=kp1_x(c1);
    c1 = c1+1;
end

J=zeros(45,8);
R2=zeros(8,1);

end
t=X_J(1:45,1)/60;
for i=1:length(Np)
J(:,i) = Hermia(X_j0(i),t,Np(i),k_x(i));
end

for i=1:length(Np)
    t=X_J(1:45,1)/60;
    j=X_J(1:45,1+i);
j(isnan(j))=0; % Convert flux missing values to 0
JJ=[t j]; idx=JJ(:,2)~=0; % Find the indices of missing values
JJ=JJ.*idx;JJ = JJ(any(JJ,2),:); % Remove missing values in the flux and corresponding time vector (because t and j needs same dimension)
j=JJ(:,2); t=JJ(:,1); % Extract time and flux   
R2(i) = 1-var(j-Hermia(X_j0(i),t,Np(i),k_x(i)))/var(j); % Calculate R square
clear j
end

end