function [Mdl_class] = svm_class(n,pred,class_model)

if class_model(1)==0
Mdl_class = fitcsvm(pred,n,'KernelFunction','rbf','OutlierFraction',class_model(2),Standardize=true);
else
Mdl_class = fitcsvm(pred,n,'KernelFunction','polynomial','PolynomialOrder',class_model(1),'OutlierFraction',class_model(2),Standardize=true);
end
end





