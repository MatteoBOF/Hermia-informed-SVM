function [J1,J2,J1_0,J2_0, R2]=validation_t(Np_t,kp0_t,kp1_t,X_Jt,X_j0_t,a_t,rtd)

c0=1;c1=1; k_x = zeros(length(Np_t),1);
for y=1:length(Np_t)
if Np_t(y)==0
    k_x(y)=kp0_t(c0);
    c0 = c0+1;
else 
    k_x(y)=kp1_t(c1);
    c1 = c1+1;
end
end

J1=zeros(60,1);
J2=zeros(121,1);
R2=zeros(1,2);


t1=X_Jt(1:60,1)/60;
a1=a_t(1,rtd); 
J1 = Hermia_tt(X_j0_t(1,rtd),t1,Np_t(1:2),k_x(1:2),a1);
R2(1) = 1-var(X_Jt(1:60,2)-J1)/var(X_Jt(1:60,2)); % Calculate R square
J1_0 = Hermia(X_j0_t(1,rtd),t1,Np_t(1),k_x(1));



t2=X_Jt(:,3)/60;
a2=a_t(2:end,1); a2=a2/0.5;
J2 = Hermia_tt(X_j0_t(3,rtd),t2,Np_t(3:end),k_x(3:end),a2);
R2(2) = 1-var(X_Jt(:,4)-J2)/var(X_Jt(:,4)); % Calculate R square
J2_0 = Hermia(X_j0_t(3,rtd),t2,Np_t(3),k_x(3));

end