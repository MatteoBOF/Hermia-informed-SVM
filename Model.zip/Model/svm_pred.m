%% Predict k
function [Mdl_k0, Mdl_k1, k0, k1, k0_x, k1_x, pred_k0, pred_k1, X_pred_k0, X_pred_k1,X_pred_t_k0,X_pred_t_k1] = svm_pred(np,Np,Np_t,k0,k1,X_k,pred,X_pred,X_pred_t,model_pred0,model_pred1)

% Check wether regression for k0 (n=0) or k1 (n=1) should be used
%indeces corresponding to n=0 and n=1
idx0=np==0; idx1=np==1; % training
IDX0=Np==0; IDX1=Np==1; % validation constant feed
IDX_t0=Np_t==0; IDX_t1=Np_t==1; 

data0 = [k0 pred];  data0=idx0.*data0;  data0 = data0(any(data0,2),:);         
data1 = [k1 pred]; data1=idx1.*data1;  data1 = data1(any(data1,2),:);         
k0 = data0(:,1);  pred_k0 = data0(:,2:end);  k1 = data1(:,1);  pred_k1 = data1(:,2:end); 

DATA0 = [X_k(:,1) X_pred]; DATA0=IDX0.*DATA0; DATA0 = DATA0(any(DATA0,2),:);
DATA1 = [X_k(:,2) X_pred]; DATA1=IDX1.*DATA1; DATA1 = DATA1(any(DATA1,2),:);
k0_x = DATA0(:,1); X_pred_k0 = DATA0(:,2:end); k1_x = DATA1(:,1); X_pred_k1 = DATA1(:,2:end);

DATA_t0=IDX_t0.*X_pred_t;  DATA_t0 = DATA_t0(any(DATA_t0,2),:); X_pred_t_k0 = DATA_t0;
DATA_t1=IDX_t1.*X_pred_t;  DATA_t1 = DATA_t1(any(DATA_t1,2),:); X_pred_t_k1 = DATA_t1;




%% Support Vector Machine Regression
if model_pred0(1)==0
Mdl_k0 = fitrsvm(pred_k0,k0*model_pred0(2),'KernelFunction','rbf','Standardize',true);
else
Mdl_k0 = fitrsvm(pred_k0,k0*model_pred0(2),'KernelFunction','polynomial','PolynomialOrder',model_pred0(1),'Standardize',true,'Epsilon',model_pred0(3));
end

if model_pred1(1)==0
Mdl_k1 = fitrsvm(pred_k1,k1*model_pred1(2),'KernelFunction','rbf','Standardize',true);
else
Mdl_k1 = fitrsvm(pred_k1,k1*model_pred1(2),'KernelFunction','polynomial','PolynomialOrder',model_pred1(1),'Standardize',true,'Epsilon',model_pred1(3));
end

end
