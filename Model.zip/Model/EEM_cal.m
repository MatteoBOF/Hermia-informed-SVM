function [train_comp,untrain_comp,untrain_t_comp] = EEM_cal(EEM,EEMx,EEMx_t,nominal_comp,training_toc,validation_toc)

n_train = 8; %numeber of training experiments
HAi = nominal_comp(1,1); Ali = nominal_comp(1,2); BSAi = nominal_comp(1,3); LMWi = nominal_comp(1,4); % Key excitation/emission wavelength
HA_train_EEM = EEM(:,HAi); BSA_train_EEM = EEM(:,[BSAi LMWi]); LMW_train_EEM = EEM(:,[BSAi LMWi]); % EEM intesity at keys ex/em - training exps
HA_val_EEM = EEMx(:,HAi); BSA_val_EEM = EEMx(:,[BSAi LMWi]); LMW_val_EEM = EEMx(:,[BSAi LMWi]); % EEM intesity at keys ex/em - validation constant feed
HA_val_t_EEM = EEMx_t(:,HAi); BSA_val_t_EEM = EEMx_t(:,[BSAi LMWi]); LMW_val_t_EEM = EEMx_t(:,[BSAi LMWi]);  % EEM intesity at keys ex/em - validation feed changes with time


% Nominal components concentrations - training exps
HA_train = nominal_comp(2:end-n_train,1).*training_toc; 
Al_train = nominal_comp(2:end-n_train,2).*training_toc;
BSA_train = nominal_comp(2:end-n_train,3).*training_toc;
LMW_train = nominal_comp(2:end-n_train,4).*training_toc;

% Nominal components concentrations - validation exps
% HA_val = nominal_comp(end-(n_train-1):end,1).*validation_toc(1:8); 
% Al_val = nominal_comp(end-(n_train-1):end,2).*validation_toc(1:8); 
% BSA_val = nominal_comp(end-(n_train-1):end,3).*validation_toc(1:8); 
% LMW_val = nominal_comp(end-(n_train-1):end,4).*validation_toc(1:8);

%% Components calibration
% Linear regression coefficients
aHA = regress(HA_train,HA_train_EEM); 
aBSA = regress(BSA_train,BSA_train_EEM); 
aLMW = regress(LMW_train,LMW_train_EEM); 

% Predicted components conc. for training exp
HA_train_p = HA_train_EEM*aHA;
BSA_train_p = sum(aBSA.*BSA_train_EEM');
LMW_train_p = sum(aLMW.*LMW_train_EEM'); 
Al_train_p = training_toc - (HA_train_p + BSA_train_p' + LMW_train_p'); 
Al_train_p = max(Al_train_p,0.13);

% Predicted components conc. for validation exp constant feed
HA_val_p = HA_val_EEM*aHA; 
BSA_val_p = sum(aBSA.*BSA_val_EEM'); 
LMW_val_p = sum(aLMW.*LMW_val_EEM'); 
Al_val_p = validation_toc(1:8) - (HA_val_p + BSA_val_p'+LMW_val_p'); Al_val_p = max(Al_val_p,0.13);

% Predicted components conc. for validation exp variable feed
HA_val_t_p = HA_val_t_EEM*aHA;
BSA_val_t_p = sum(aBSA.*BSA_val_t_EEM');
LMW_val_t_p = sum(aLMW.*LMW_val_t_EEM'); 
Al_val_t_p = validation_toc(9:end) - (HA_val_t_p + BSA_val_t_p'+LMW_val_t_p');  Al_val_t_p = max(Al_val_t_p,0.13);


% Store the predicted compositions for training, validation constant feed
% and validation variable feed
train_comp = [HA_train_p Al_train_p BSA_train_p' LMW_train_p'];
untrain_comp = [HA_val_p Al_val_p BSA_val_p' LMW_val_p']; 
untrain_t_comp = [HA_val_t_p Al_val_t_p BSA_val_t_p' LMW_val_t_p']; 
end