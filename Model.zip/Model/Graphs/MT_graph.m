function [T,L] = MT_graph(pred,X_pred,n_t,Np,Mdl_class,leg,k0,k1,kp0,kp1,k0_x,k1_x,kp0_x,kp1_x)
R=[0.76	0.16 0.18];
B=[0.01 0.13 0.47];
sv = Mdl_class.SupportVectors;
sv = Mdl_class.Mu + sv.*Mdl_class.Sigma; %scale back the Support Vectors

for i=1:length(n_t)
    if n_t(i)==0
        col(i,:)=B;
    else
        col(i,:)=R;
    end
end


R0 = 1-(sum((k0-kp0).^2))./sum((k0-mean(k0)).^2);
R1 = 1-(sum((k1-kp1).^2))./sum((k1-mean(k1)).^2);


T=tiledlayout(1,7); 
nexttile([1 3])
set(gcf,'Visible','on')
scatter3(pred(:,1),pred(:,2),pred(:,3),10,col,'filled','SizeData',50,'MarkerEdgeColor','k');
    %'MarkerEdgeColor','b' );
xlabel('Initial Flux (L m^{-2} h^{-1})','fontweight','bold','fontsize',12);ylabel('TOC (mgC L^{-1})','fontweight','bold','fontsize',12);zlabel('Alginate content (%)','fontweight','bold','fontsize',12);
hold on
scatter3(X_pred(:,1),X_pred(:,2),X_pred(:,3),10,R,'filled','SizeData',50,'MarkerEdgeColor','k');
hold on
plot3(sv(:,1),sv(:,2),sv(:,3),'ko','MarkerSize',10,'LineWidth',0.5)
hold on
scatter3(X_pred(:,1),X_pred(:,2),X_pred(:,3),10,categorical(Np),'filled','SizeData',50,'MarkerEdgeColor','k', 'MarkerFaceColor',[0 .75 .75])
hold on
 numGrid = 100;
[x1Grid,x2Grid,x3Grid] = meshgrid(linspace(125,475,numGrid),...
     linspace(2.5,9.5,numGrid),linspace(0,70,numGrid));
xList = [x1Grid(:),x2Grid(:),x3Grid(:)];
[~,scores] = predict(Mdl_class,xList);
[faces,verts] = isosurface(x1Grid,x2Grid,x3Grid, reshape(scores(:,2),size(x1Grid)),0);
p=patch('Vertices', verts, 'Faces', faces, 'FaceColor','k','edgecolor', 'none', 'FaceAlpha', 0.75);
p.FaceColor = [0.5 0.5 0.5];
grid on; box on
title('A')
 if leg==1
 legend('n=0, Intermediate Blocking','n=1, Cake Filtration','Support Vectors','Validation Experiments','NumColumns',3,'Location','northoutside');
 end


nexttile([1 2])
plot([0 max(max(kp0),max(k0))]*1.25,[0 max(max(kp0),max(k0))]*1.25,'Color',[0.8,0.8,0.8],'LineWidth',2)
hold on
T1 = scatter(k0,kp0,30,'LineWidth',1,'MarkerEdgeColor',[0.3 0.3 0.3]);
hold on
V1 = scatter(k0_x,kp0_x,'filled','MarkerEdgeColor',[0.3 0.3 0.3], 'MarkerFaceColor',[0 .75 .75]);
xlim([0 max(max(kp0),max(k0))]*1.25); ylim([0 max(max(kp0),max(k0))]*1.25);
xlabel('Oberved K_0 (L^{-2} m^4 h)','fontweight','bold','fontsize',12); ylabel('Predicted K_0 (L^{-2} m^4 h)','fontweight','bold','fontsize',12)
title('B')
legend([T1,V1],'Training','Validation','Location','southeast')


nexttile([1 2])
plot([0 max(max(kp1),max(k1))]*1.25,[0 max(max(kp1),max(k1))]*1.25,'Color',[0.8,0.8,0.8],'LineWidth',2)
hold on
T2 = scatter(k1,kp1,30,'LineWidth',1,'MarkerEdgeColor',[0.3 0.3 0.3]);
hold on
V2 = scatter(k1_x,kp1_x,'filled','MarkerEdgeColor',[0.3 0.3 0.3], 'MarkerFaceColor',[0 .75 .75]);
xlim([0 max(max(kp1),max(k1))]*1.25); ylim([0 max(max(kp1),max(k1))]*1.25);
xlabel('Oberved K_1 (L^{-1} m^2)','fontweight','bold','fontsize',12); ylabel('Predicted K_1 (L^{-1} m^2)','fontweight','bold','fontsize',12)
title('C')
legend([T2,V2],'Training','Validation','Location','southeast')


end