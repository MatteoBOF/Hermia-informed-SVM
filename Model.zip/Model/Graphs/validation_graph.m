function [T1,T2,T3] = validation_graph(Np,J,X_J,X_Jt,J1,J2,J1_0,J2_0,R2,R2_t,toc,untrain_t,a_t)

R=[0.76	0.16 0.18];
B=[0.01 0.13 0.47];
Br2 = [0.721568627	0.450980392	0.2];
Br1 = [0.282352941	0.235294118	0.196078431];
%% Untrained data 1
figure ()
str=['A' 'B' 'C' 'D' 'E' 'F' 'G' 'H'];

aa = [1;4;5;8;2;3;6;7]; nn = [1;0;1;1;0;1;1;0]; ll=[270 270 270 270 450 450 450 450];
T1=tiledlayout(2,4,'TileSpacing', 'compact'); %Outer layout
for ii=1:length(Np)
nexttile
i=aa(ii);
if nn(ii)==0
    col=B;
else
    col=R;
end

scatter(X_J(1:45,1),X_J(1:45,i+1),30,'LineWidth',1,'MarkerEdgeColor',[0.5 0.5 0.5])
hold on
plot(X_J(1:45,1),J(:,i),'LineWidth',3,'Color',col)
xlim([0 45]); ylim([0 ll(ii)])
txt = ['R^2 =' num2str(R2(i),'%4.2f')];
NE = [max(xlim) max(ylim)]-[diff(xlim) diff(ylim)]*0.05;
text(NE(1),NE(2),txt,'VerticalAlignment','top', 'HorizontalAlignment','right');
title(str(ii))
box on
end

xlabel(T1,'Time (min)','fontweight','bold','fontsize',12); 
ylabel(T1,'Flux (L m^{-2} h^{-1})','fontweight','bold','fontsize',12);

toc1 = toc(9:10,1); al1 = untrain_t(1:2,2); Al1 = (al1./toc1)*100;
toc2 = toc(11:end,1); al2 = untrain_t(3:end,2); Al2 = (al2./toc2)*100;
tsp1 = [0;a_t(1,2);a_t(1,2);60]; TOC1 = [toc1(1); toc1(1); toc1(2); toc1(2)]; AL1 = [Al1(1); Al1(1); Al1(2); Al1(2)];
tsp2 = [0;a_t(2:end,2);60]; TOC2 = [toc2(1);toc2(1:end)]; AL2 = [Al2(1);Al2(1:end)];


figure ()
T2 = tiledlayout(1,2,'TileSpacing','compact');
t1=tiledlayout(T2,2,1,'TileSpacing','tight'); % Inner layout
nexttile(t1)
yyaxis left
plot(tsp1,TOC1,'-.o','LineWidth',1,'Color',Br1,'MarkerSize',4,'MarkerEdgeColor',Br1,...
    'MarkerFaceColor',Br1)
ylabel('TOC (mg L^{-1})','fontweight','bold','fontsize',12);
ylim([0 9]); xlim([0 45]);
yyaxis right 
plot(tsp1,AL1,'-.o','LineWidth',1,'Color',Br2,'MarkerSize',4,'MarkerEdgeColor',Br2,...
    'MarkerFaceColor',Br2)
ylim([0 60]); xlim([0 45]);
legend('TOC','Alginate','Location','southeast')
ax = gca;
ax.YAxis(1).Color = Br1;
ax.YAxis(2).Color = Br2;
xlim([0 45])
title('A')
nexttile(t1)
scatter(X_Jt(1:45,1),X_Jt(1:45,2),30,'LineWidth',1,'MarkerEdgeColor',[0.5 0.5 0.5])
hold on
plot(X_Jt(1:45,1),J1(1:45),'LineWidth',3,'Color',R)
hold on
plot(X_Jt(1:45,1),J1_0(1:45),':','LineWidth',1,'Color',R)
ylim([0 350]); xlim([0 45]);
ylabel('Flux (L m^{-2} h^{-1})','fontweight','bold','fontsize',12);
box on
txt = ['R^2 =' num2str(R2_t(1),'%4.2f')];
NE = [max(xlim) max(ylim)]-[diff(xlim) diff(ylim)]*0.05;
text(NE(1),NE(2),txt,'VerticalAlignment','top', 'HorizontalAlignment','right');

t2=tiledlayout(T2,2,1,'TileSpacing','tight'); % Inner layout
t2.Layout.Tile = 2;
nexttile(t2)
yyaxis left
plot(tsp2,TOC2,'-.o','LineWidth',1,'Color',Br1,'MarkerSize',4,'MarkerEdgeColor',Br1,...
    'MarkerFaceColor',Br1);
ylim([0 9]); xlim([0 45]);
yyaxis right
plot(tsp2,AL2,'-.o','LineWidth',1,'Color',Br2,'MarkerSize',4,'MarkerEdgeColor',Br2,...
    'MarkerFaceColor',Br2);
ylim([0 60]); xlim([0 45]);
ylabel('Alginate (%)','fontweight','bold','fontsize',12);
legend('TOC','Alginate','Location','northwest')
ax = gca;
ax.YAxis(1).Color = Br1;
ax.YAxis(2).Color = Br2;
xlim([0 45])
title('B')
nexttile(t2)
scatter(X_Jt(1:90,3),X_Jt(1:90,4),30,'LineWidth',1,'MarkerEdgeColor',[0.5 0.5 0.5])
hold on
plot(X_Jt(1:90,3),J2(1:90),'LineWidth',3,'Color',R)
hold on
plot(X_Jt(1:90,3),J2_0(1:90),':','LineWidth',1,'Color',R)
ylim([0 350]); xlim([0 45]);
box on
txt = ['R^2 =' num2str(R2_t(2),'%4.2f')];
NE = [max(xlim) max(ylim)]-[diff(xlim) diff(ylim)]*0.05;
text(NE(1),NE(2),txt,'VerticalAlignment','top', 'HorizontalAlignment','right');

xlabel(T2,'Time (min)','fontweight','bold','fontsize',12); 

% figure()
% clear i
% i=2;
% T3 = tiledlayout(2,1,'TileSpacing','tight');
% nexttile
% scatter(X_J(1:45,1),X_J(1:45,i+1),30,'LineWidth',1,'MarkerEdgeColor',[0.5 0.5 0.5])
% hold on
% plot(X_J(1:45,1),J(:,i),'LineWidth',3,'Color',col)
% xlim([0 45]); 
% %ylim([0 ll(ii)])
% txt = ['R^2 =' num2str(R2(i),'%4.2f')];
% NE = [max(xlim) max(ylim)]-[diff(xlim) diff(ylim)]*0.05;
% text(NE(1),NE(2),txt,'VerticalAlignment','top', 'HorizontalAlignment','right');
% box on
% nexttile
% scatter(X_Jt(1:45,1),X_Jt(1:45,2),30,'LineWidth',1,'MarkerEdgeColor',[0.5 0.5 0.5])
% hold on
% plot(X_Jt(1:45,1),J1(1:45),'LineWidth',3,'Color',R)
% hold on
% plot(X_Jt(1:45,1),J1_0(1:45),':','LineWidth',1,'Color',R)
% ylim([0 350]); xlim([0 45]);
% box on
% txt = ['R^2 =' num2str(R2_t(1),'%4.2f')];
% NE = [max(xlim) max(ylim)]-[diff(xlim) diff(ylim)]*0.05;
% text(NE(1),NE(2),txt,'VerticalAlignment','top', 'HorizontalAlignment','right');
% 
% xlabel(T3,'Time (min)','fontweight','bold','fontsize',12); 
% ylabel(T3,'Flux (L m^{-2} h^{-1})','fontweight','bold','fontsize',12);
end