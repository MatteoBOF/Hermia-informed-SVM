
function J=Hermia(j0,tt,n,k)
%j0 = j0/60;
tspan = tt;
%tspan = tspan/60;
y0 = 1/j0;

[t,y] = ode45(@(t,y) k*(y^(n-1)),tspan,y0);

J = 1./y;
% %t=t*60;
%  plot(t,J)
%  hold on
end