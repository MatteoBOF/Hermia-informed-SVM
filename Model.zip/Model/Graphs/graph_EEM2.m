

function [t0,t1,t2]=graph_EEM2(EEMx,EEMx_t,Ex,Em)
ff = 1:1:60;
FF = 2*ff;
%% Import all data
%training_J(:,[5 12])=[];

%[EEM,~,~,Ex,Em]=Import_EEM();
EEM=max(EEMx,0);
EEMt=max(EEMx_t,0);
a = 0; b=1.2;
x = [min(Em) 400]; 
%x =[min(Em) max(Em)];
y = [min(Ex) 600]; 
%y =[min(Ex) max(Ex)];
l=200;




figure()
t0=tiledlayout(2,4,'TileSpacing','tight'); %Outer layout
nexttile
A3=reshape(EEM(1,:),length(Ex),length(Em));
contourf(Em,Ex,A3,l,'edgecolor','none')
clim([0 2]); 
xlim(x); ylim(y); colormap(turbo); 
title('A')
nexttile
A4=reshape(EEM(4,:),length(Ex),length(Em));
contourf(Em,Ex,A4,l,'edgecolor','none')
clim([0 2]); 
xlim(x); ylim(y); colormap(turbo); 
title('B')
nexttile
A5=reshape(EEM(5,:),length(Ex),length(Em));
contourf(Em,Ex,A5,l,'edgecolor','none')
clim([0 2]); 
xlim(x); ylim(y); colormap(turbo); 
title('C')
nexttile
A6=reshape(EEM(8,:),length(Ex),length(Em));
contourf(Em,Ex,A6,l,'edgecolor','none')
clim([0 2]); 
xlim(x); ylim(y); colormap(turbo); 
title('D')
nexttile
A7=reshape(EEM(2,:),length(Ex),length(Em));
contourf(Em,Ex,A7,l,'edgecolor','none')
clim([0 2]); 
xlim(x); ylim(y); colormap(turbo); 
title('E')
nexttile
A8=reshape(EEM(3,:),length(Ex),length(Em));
contourf(Em,Ex,A8,l,'edgecolor','none')
clim([0 2]); 
xlim(x); ylim(y); colormap(turbo); 
title('F')
nexttile
A9=reshape(EEM(6,:),length(Ex),length(Em));
contourf(Em,Ex,A9,l,'edgecolor','none')
clim([0 2]); 
xlim(x); ylim(y); colormap(turbo); 
title('G')
nexttile
A10=reshape(EEM(7,:),length(Ex),length(Em));
contourf(Em,Ex,A10,l,'edgecolor','none')
clim([0 2]); 
xlim(x); ylim(y); colormap(turbo); 
title('H')
xlabel(t0,'Ex Wavelength (nm)','fontweight','bold','fontsize',12); ylabel(t0,'Em Wavelength (nm)','fontweight','bold','fontsize',12)
cb = colorbar;
cb.Layout.Tile = 'east';


clear A3 A4 A5 A6 A7 A8


figure()
t1=tiledlayout(1,2); %Outer layout
nexttile
A1=reshape(EEMt(1,:),length(Ex),length(Em));
contourf(Em,Ex,A1,l,'edgecolor','none')
clim([0 1.3]); 
xlim(x); ylim(y); colormap(turbo); 
title('0 min')
nexttile
A2=reshape(EEMt(2,:),length(Ex),length(Em));
contourf(Em,Ex,A2,l,'edgecolor','none')
clim([0 1.3]); 
xlim(x); ylim(y); colormap(turbo); 
title('10 min')
xlabel(t1,'Ex Wavelength (nm)','fontweight','bold','fontsize',12); ylabel(t1,'Em Wavelength (nm)','fontweight','bold','fontsize',12)
cb = colorbar;
cb.Layout.Tile = 'east';

figure()
t2=tiledlayout(2,4,'TileSpacing','tight'); %Outer layout
nexttile
A3=reshape(EEMt(3,:),length(Ex),length(Em));
contourf(Em,Ex,A3,l,'edgecolor','none')
clim([0 2]); 
xlim(x); ylim(y); colormap(turbo); 
title('0 min')
nexttile
A4=reshape(EEMt(4,:),length(Ex),length(Em));
contourf(Em,Ex,A4,l,'edgecolor','none')
clim([0 2]); 
xlim(x); ylim(y); colormap(turbo); 
title('10 min')
nexttile
A5=reshape(EEMt(5,:),length(Ex),length(Em));
contourf(Em,Ex,A5,l,'edgecolor','none')
clim([0 2]); 
xlim(x); ylim(y); colormap(turbo); 
title('15 min')
nexttile
A6=reshape(EEMt(6,:),length(Ex),length(Em));
contourf(Em,Ex,A6,l,'edgecolor','none')
clim([0 2]); 
xlim(x); ylim(y); colormap(turbo); 
title('20 min')
nexttile
A7=reshape(EEMt(7,:),length(Ex),length(Em));
contourf(Em,Ex,A7,l,'edgecolor','none')
clim([0 2]); 
xlim(x); ylim(y); colormap(turbo); 
title('25 min')
nexttile
A8=reshape(EEMt(8,:),length(Ex),length(Em));
contourf(Em,Ex,A8,l,'edgecolor','none')
clim([0 2]); 
xlim(x); ylim(y); colormap(turbo); 
title('30 min')
nexttile
A9=reshape(EEMt(9,:),length(Ex),length(Em));
contourf(Em,Ex,A9,l,'edgecolor','none')
clim([0 2]); 
xlim(x); ylim(y); colormap(turbo); 
title('35 min')
nexttile
A10=reshape(EEMt(10,:),length(Ex),length(Em));
contourf(Em,Ex,A10,l,'edgecolor','none')
clim([0 2]); 
xlim(x); ylim(y); colormap(turbo); 
title('40 min')

xlabel(t2,'Ex Wavelength (nm)','fontweight','bold','fontsize',12); ylabel(t2,'Em Wavelength (nm)','fontweight','bold','fontsize',12)
cb = colorbar;
cb.Layout.Tile = 'east';


end