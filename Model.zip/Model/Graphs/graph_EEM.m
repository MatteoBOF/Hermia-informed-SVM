

function T=graph_EEM(EEM,Ex,Em,comp,toc, u_toc,train_c,untrain_c)
ff = 1:1:60;
FF = 2*ff;


EEM=max(EEM,0);
a = 0; b=1.2;
x = [min(Em) 400]; 
%x =[min(Em) max(Em)];
y = [min(Ex) 600]; 
%y =[min(Ex) max(Ex)];
l=200;
AA(1,:) = EEM(17,:);
AA(2,:) = EEM(26,:); 
AA(3,:) = EEM(28,:); 

HAc=comp(2:31,1).*toc; Alc=comp(2:31,2).*toc; BSAc=comp(2:31,3).*toc; LMWc=comp(2:31,4).*toc;
HAp=train_c(:,1); Alp=train_c(:,2); BSAp=train_c(:,3); LMWp=train_c(:,4);
% R_HA = 1-(sum((HAc-HAp).^2))./sum((HAc-mean(HAc)).^2);
% R_Al = 1-(sum((Alc-Alp).^2))./sum((Alc-mean(Alp)).^2);
% R_BSA = 1-(sum((BSAc-BSAp).^2))./sum((BSAc-mean(BSAc)).^2);
% R_LMW = 1-(sum((LMWc-LMWp).^2))./sum((LMWc-mean(LMWc)).^2);

HAuc=comp(32:end,1).*u_toc(1:8); Aluc=comp(32:end,2).*u_toc(1:8); BSAuc=comp(32:end,3).*u_toc(1:8); LMWuc=comp(32:end,4).*u_toc(1:8);
HAup=untrain_c(:,1); Alup=untrain_c(:,2); BSAup=untrain_c(:,3); LMWup=untrain_c(:,4);


str=['A' 'B' 'C'];
T=tiledlayout(2,1); %Outer layout

t1=tiledlayout(T,1,3,'TileSpacing','Compact'); % Inner layout
%t1.Layout.Tile = 1;
for ii=1:3
    nexttile(t1)
  A=AA(ii,:);  A=reshape(A,length(Ex),length(Em));
contourf(Em,Ex,A,l,'edgecolor','none')
clim([0 2.5]); 
xlim(x); ylim(y); colormap(turbo); 
%colorbar
title(str(ii))
clear A
if ii~=1
    set(gca,'yticklabel',[])
end
end
cb = colorbar();
cb.Layout.Tile = 'east';

xlabel(t1,'Ex Wavelength (nm)','fontweight','bold','fontsize',12); ylabel(t1,'Em Wavelength (nm)','fontweight','bold','fontsize',12)


t2=tiledlayout(T,1,4,'TileSpacing','Compact'); % Inner layout
t2.Layout.Tile = 2;
nexttile(t2)
plot([0 max(max(HAc),max(HAp))]*1.25,[0 max(max(HAc),max(HAp))]*1.25,'Color',[0.8,0.8,0.8],'LineWidth',2)
hold on
T=scatter(HAc,HAp,30,'LineWidth',1,'MarkerEdgeColor',[0.3 0.3 0.3]);
hold on
V=scatter(HAuc,HAup,40,'filled','MarkerEdgeColor',[0.3 0.3 0.3], 'MarkerFaceColor',[0 .75 .75]);
xlim([0 max(max(HAc),max(HAp))]*1.25);
ylim([0 max(max(HAc),max(HAp))]*1.25);
title('D')
legend([T V],'Training','Validation', 'Location','northwest')
SE = [max(xlim) min(ylim)]+[-diff(xlim) diff(ylim)]*0.05;
text(SE(1),SE(2),'HA','VerticalAlignment','bottom', 'HorizontalAlignment','right')
% txt = ['R2 =' num2str(R_HA,'%4.3f')];
% NW = [min(xlim) max(ylim)]+[diff(xlim) -diff(ylim)]*0.05;
% text(NW(1),NW(2),txt)

nexttile(t2)
plot([0 max(max(Alc),max(Alp))]*1.25,[0 max(max(Alc),max(Alp))]*1.25,'Color',[0.8,0.8,0.8],'LineWidth',2)
hold on
T1 = scatter(Alc,Alp,30,'LineWidth',1,'MarkerEdgeColor',[0.3 0.3 0.3]);
hold on
V1 = scatter(Aluc,Alup,40,'filled','MarkerEdgeColor',[0.3 0.3 0.3], 'MarkerFaceColor',[0 .75 .75]);
xlim([0 max(max(Alc),max(Alp))]*1.25);
ylim([0 max(max(Alc),max(Alp))]*1.25);
title('E')
legend([T1,V1],'Training','Validation','Location','northwest')
SE = [max(xlim) min(ylim)]+[-diff(xlim) diff(ylim)]*0.05;
text(SE(1),SE(2),'Alginate','VerticalAlignment','bottom', 'HorizontalAlignment','right')
% txt = ['R2 =' num2str(R_Al,'%4.3f')];
% NW = [min(xlim) max(ylim)]+[diff(xlim) -diff(ylim)]*0.05;
% text(NW(1),NW(2),txt)



nexttile(t2)
plot([0 max(max(BSAc),max(BSAp))]*1.25,[0 max(max(BSAc),max(BSAp))]*1.25,'Color',[0.8,0.8,0.8],'LineWidth',2)
hold on
T2=scatter(BSAc,BSAp,30,'LineWidth',1,'MarkerEdgeColor',[0.3 0.3 0.3]);
hold on
V2=scatter(BSAuc,BSAup,40,'filled','MarkerEdgeColor',[0.3 0.3 0.3], 'MarkerFaceColor',[0 .75 .75]);
xlim([0 max(max(BSAc),max(BSAp))]*1.25);
ylim([0 max(max(BSAc),max(BSAp))]*1.25);
title('F')
legend([T2 V2],'Training','Validation','Location','northwest')
SE = [max(xlim) min(ylim)]+[-diff(xlim) diff(ylim)]*0.05;
text(SE(1),SE(2),'BSA','VerticalAlignment','bottom', 'HorizontalAlignment','right')
% txt = ['R^2 =' num2str(R_BSA,'%4.3f')];
% NW = [min(xlim) max(ylim)]+[diff(xlim) -diff(ylim)]*0.05;
% text(NW(1),NW(2),txt)

nexttile(t2)
plot([0 max(max(LMWc),max(LMWp))]*1.25,[0 max(max(LMWc),max(LMWp))]*1.25,'Color',[0.8,0.8,0.8],'LineWidth',2)
hold on
T3=scatter(LMWc,LMWp,30,'LineWidth',1,'MarkerEdgeColor',[0.3 0.3 0.3]);
hold on
V3=scatter(LMWuc,LMWup,40,'filled','MarkerEdgeColor',[0.3 0.3 0.3], 'MarkerFaceColor',[0 .75 .75]);
xlim([0 max(max(LMWc),max(LMWp))]*1.25);
ylim([0 max(max(LMWc),max(LMWp))]*1.25);
title('G')
legend([T3 V3],'Training','Validation','Location','northwest')
SE = [max(xlim) min(ylim)]+[-diff(xlim) diff(ylim)]*0.05;
text(SE(1),SE(2),'LMW','VerticalAlignment','bottom', 'HorizontalAlignment','right')
% txt = ['R^2 =' num2str(R_LMW,'%4.3f')];
% NW = [min(xlim) max(ylim)]+[diff(xlim) -diff(ylim)]*0.05;
% text(NW(1),NW(2),txt)



xlabel(t2,'Expected Conc. (mg L^{-1})','fontweight','bold','fontsize',12); ylabel(t2,'Predicted Conc. (mg ^{-1})','fontweight','bold','fontsize',12)

end