clc
clear
close all
main_dir = 'C:...\Model';
Data_dir = 'C:...\Model\Data';
EEM_dir = 'C:...\Model\Data\EEM_raw';
Graphs_dir = 'C:...\Model\Graphs';

%Hermia-informend SVM algoritm to predict water flux based on EEM spectra

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% IMPORT DATA  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd(Data_dir)
%% Import fluorescence data
% EEM: training experiments
% EEMx: validation experiments at constant feed composition
% EEMx_t: validation experiments with time-dependent feed composition

[EEM,EEMx,EEMx_t,Ex,Em]=Import_EEM(EEM_dir, Data_dir);

%% Import Flux Decline and extract the initial fluxes
training_J = readtable('training_fluxes.xlsx'); training_J = table2array(training_J); % Training Flux Decline
X_J = readtable('validation_fluxes.xlsx'); X_J = table2array(X_J); X_j0 = X_J(1,2:end)';  % VAlidation Flux Decline for constant feed
X_Jt = readtable('validation_fluxes_t.xlsx'); X_Jt = table2array(X_Jt); % Validation Flux Decline for sudden feed change (:,1:2) and stepwise feed change(:,3:4)

% Residence Time Distribution Factor (to accound for dead-volume impact on composition change
a_j0_t = readtable('a_j0.xlsx'); a_j0_t = table2array(a_j0_t);  % Column 1:3 contains the time when feed compostion change (for 1,2,4 min rtd factor); Raw 1: sudden change, Raw2: Stepwise change
a_t=a_j0_t(:,1:3);

% Extract initial fluxes for variable feed experiments (after every feed change)
X_j0_t = ones(10,3);
X_j0_t(1,:)= X_Jt(1,2)*X_j0_t(1,:); %Initial Flux sudden feed change exps
X_j0_t(2,:)=a_j0_t(1,4:6); % Flux when feed composition is changed for sudden change
X_j0_t(3,:)= X_Jt(1,4)*X_j0_t(3,:); % Initial Flux for step-wise change
X_j0_t(4:end,:)=a_j0_t(2:end,4:6); % Fluxes when feed composition is changed for step-wise change

%% Import TOC analysis and nominal composition
training_toc = readtable('train_toc.xlsx'); training_toc = table2array(training_toc); % TOC analysis of feed for training exps
validation_toc = readtable('val_toc.xlsx'); validation_toc=table2array(validation_toc); % TOC analysis of feed for validation exps (1-8: constant Feed; 9-10: sudden change; 11-18: stepwise change)

% nominal (desired composition): humic acid, alginate, BSA, LMWs relative to TPC 1sr raw: key excitation/emission (linearized); 2-31: training exps; 32-39: validation (constant feed) exps
nominal_comp=readtable('train_val_composition.xlsx'); nominal_comp = table2array(nominal_comp); 

%% residence time distribution factor (1,2,3)
rtd=2;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% MODEL TRAINING and VALIDATION %%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd(main_dir)

%% EEM calibration
% train_c : training exps, predicted toc, HA, Al, BSA and LMW
% untrain_c : untrained exps, predicted toc, HA, Al, BSA and LMW
[train_comp,untrain_comp,untrain_t_comp] = EEM_cal(EEM,EEMx,EEMx_t,nominal_comp,training_toc,validation_toc);

%% Hermia Fitting to training data

% n_t = dominant fouling mechanism
% k0 = k parameters for n=0
% k1 = k parameters for n=1
% j0 = initial fluxes
% 95% confidence interval for k
% PAR = [0 1 k0 k1 IC_k0 IC_k1 R2_k0 R2_k1 j0]
% [n_t,k0,k1,j0,~,IC,~,PAR]=training_Hermia(training_J);

[n_t,k0,k1,j0,~,IC,~,PAR]=training_Hermia(training_J);
n_t(16)=1; % n for experiment 16 manually set to 1, see Tagliavini & Snyder ACS EST Water 2024

%% Fitting Hermia to validation exps (constat feed) to compare predicted vs
% observed k parameter
X_k = validation_Hermia(X_J);

%% Predictor matrices 
% Training 
pred = zeros(size(j0,1),3);
pred(:,1) = j0;
pred(:,2) = training_toc;
pred(:,3) = (train_comp(:,2)./training_toc)*100;

% Validation Constant Feed
X_pred = zeros(size(untrain_comp,1),3);
X_pred(:,1) = X_j0;
X_pred(:,2) = validation_toc(1:8);
X_pred(:,3) = (untrain_comp(:,2)./validation_toc(1:8))*100;

% Validation variable feed
X_pred_t = zeros(size(untrain_t_comp,1),3);
X_pred_t(:,1) = X_j0_t(:,rtd);
X_pred_t(:,2) = validation_toc(9:end);
X_pred_t(:,3) = (untrain_t_comp(:,2)./validation_toc(9:end))*100;


%% Support Vector Classification
class_model = [2 0.1]; % 0: radial basis function, 1/2/3 polynomial order, box constraint
[Mdl_class] =  svm_class(n_t,pred(:,1:3),class_model); % Train a SVM binary classification model (Mdl_class) for n=0 or n=1
np = predict(Mdl_class,pred(:,1:3)); % predicted n parameter for training exps
Np = predict(Mdl_class,X_pred(:,1:3)); % predicted n parameter for validation exps at constant feed
Np_t = predict(Mdl_class,X_pred_t(:,1:3)); % predicted n parameter for validation exps at variable feed

%% Support Vector Regression
model_pred0 = [2 1e3 max(PAR(:,5))]; %0: radial basis function, 1/2/3 polynomial order / scaling factor / epsilon
model_pred1 = [3 1e3 max(PAR(:,6))]; % 0: radial basis function, 1/2/3 polynomial order / scaling factor / epsilon

% Train a regression for k0 (Mdl_k0) or k1 (Mdl_k1) based on the SVM classification outcome
[Mdl_k0, Mdl_k1, k0, k1, k0_x, k1_x, pred_k0, pred_k1, X_pred_k0, X_pred_k1,X_pred_t_k0,X_pred_t_k1] ...
    = svm_pred(np,Np,Np_t,k0,k1,X_k,pred,X_pred,X_pred_t,model_pred0,model_pred1); 

kp0 = predict(Mdl_k0,pred_k0)/model_pred0(2);  % predicted k0 parameter for training exps
kp1 = predict(Mdl_k1,pred_k1)/model_pred1(2);  % predicted k1 parameter for training exps

kp0_x = predict(Mdl_k0,X_pred_k0)/model_pred0(2); % predicted k0 parameter for validation exps at constant feed
kp1_x = predict(Mdl_k1,X_pred_k1)/model_pred1(2); % predicted k1 parameter for validation exps at constant feed

kp0_t = predict(Mdl_k0,X_pred_t_k0)/model_pred0(2); % predicted k0 parameter for validation exps at variable feed
kp1_t = predict(Mdl_k1,X_pred_t_k1)/model_pred1(2); % predicted k1 parameter for validation exps at variable feed

%% Simulate-observed untrained data
% Constant Feed
[t ,J,R2]=validation(Np,kp0_x,kp1_x,X_J);
%Variable Feed
[J1,J2,J1_0,J2_0,R2_t]=validation_t(Np_t,kp0_t,kp1_t,X_Jt,X_j0_t,a_t,rtd);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% PLOT GRAPHS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cd(Graphs_dir);

%% PLOT EEM calibration
figure ()
G1 = graph_EEM(EEM,Ex,Em,nominal_comp,training_toc, validation_toc,train_comp,untrain_comp);

%% PLOT SI unknown EEM
%[G_SI2, G_SI3] = graph_EEM2(EEMx,EEMx_t,Ex,Em);

%% Model Training Graphs
leg=1;
n_t(16)=0;
figure()
G3 = MT_graph(pred,X_pred,n_t,Np,Mdl_class,leg,k0,k1,kp0,kp1,k0_x,k1_x,kp0_x,kp1_x);

%% Untrained data 1
[G4,G5] = validation_graph(Np,J,X_J,X_Jt,J1,J2,J1_0,J2_0,R2,R2_t,validation_toc,untrain_t_comp,a_t);
